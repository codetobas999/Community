import numpy as np

data = [20, 40, 60, 80, 100]
arr = np.array(data, np.float)

print('------------------------------------')
print(arr.dtype)
print(type(arr))
print(arr)
