import random as rd

data = []
for i in range(0, 10):
    data.append(rd.randint(1, 100))

print("------------------------------------")
print(data)
print(type(data))
