import numpy as np

arr = np.array([[100, 200, 300], [2000, 4000, 6000]], np.int)

print(arr.shape)
print(type(arr))
