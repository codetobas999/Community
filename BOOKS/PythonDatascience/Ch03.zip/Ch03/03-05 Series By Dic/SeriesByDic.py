import pandas as pd

dic = {"สมศรี":167, "พิมพ์พร":170, "สุดใจ":165, "สมหญิง":164}
ps = pd.Series(dic)

print("------------------------------------")
print(type(dic))
print(ps)
