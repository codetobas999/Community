import pandas as pd
 
df = pd.read_excel ('Product.xlsx')
print(type(df))
print(df)