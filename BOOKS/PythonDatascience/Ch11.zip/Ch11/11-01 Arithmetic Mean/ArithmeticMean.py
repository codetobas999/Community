import numpy as np

data = [170, 175, 180, 174, 183, 178]
print(np.mean(data))

