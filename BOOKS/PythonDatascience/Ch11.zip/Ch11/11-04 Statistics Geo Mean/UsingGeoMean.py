import statistics as st

data = [5, 7]
result = st.geometric_mean(data)

print('{0:.3f}'.format(result))


