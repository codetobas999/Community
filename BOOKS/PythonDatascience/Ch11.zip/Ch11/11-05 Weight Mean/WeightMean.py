import numpy as np

result = np.average([200, 250, 300], weights=[4, 3, 2])
print(result)
