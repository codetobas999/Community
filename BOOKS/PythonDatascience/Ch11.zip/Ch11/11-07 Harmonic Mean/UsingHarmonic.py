import statistics as st

data = [78.5, 67.3, 70.1, 65.2, 75.9]
result = st.harmonic_mean(data)

print('ความเร็ว : ', result)

