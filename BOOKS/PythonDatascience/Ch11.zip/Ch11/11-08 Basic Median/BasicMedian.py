import numpy as np

data = [20, 12, 19, 17, 16]
result = np.median(data)

print(result)
