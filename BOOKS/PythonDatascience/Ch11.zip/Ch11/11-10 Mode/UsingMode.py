import statistics as st

data = [10, 8, 9, 10, 5, 7, 10, 5, 1, 2]
result = st.mode(data)

print('ฐานนิยม : ', result)

