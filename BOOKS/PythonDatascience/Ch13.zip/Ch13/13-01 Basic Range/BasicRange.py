import numpy as np

data = [30, 15, 14, 17, 20, 22, 29, 40, 19]
arr = np.array(data)

Minimum = min(data)
Maximum = max(data)
print('Range : ', Maximum - Minimum)

