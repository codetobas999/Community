import pandas as pd

data = [10, 15, 16, 20, 17]
df = pd.DataFrame(data)
print(df.mad())


