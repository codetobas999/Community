from scipy.stats import variation

a = [20, 11, 12, 10, 9]
b = [15, 16, 17, 18, 17]

print('ค่าสัมประสิทธิ์ของการแปรผัน A : ', variation(a))
print('ค่าสัมประสิทธิ์ของการแปรผัน B : ', variation(b))

