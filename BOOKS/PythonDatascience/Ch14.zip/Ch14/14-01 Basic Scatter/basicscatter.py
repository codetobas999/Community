import matplotlib.pyplot as plt

x = [1, 2, 3, 4]
y = [2, 4, 6, 8]

plt.scatter(x, y)
plt.title('Sale Values')
plt.xlabel('X Data')
plt.ylabel('Y Data')
plt.show()

