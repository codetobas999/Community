import matplotlib.pyplot as plt

x1 = [1, 2, 3, 4]
y1 = [2, 4, 6, 8]

x2 = [0, 4, 8, 11]
y2 = [2, 5, 6, 12]

plt.scatter(x1, y1)
plt.scatter(x2, y2)
plt.show()
