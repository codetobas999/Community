import matplotlib.pyplot as plt

x = [5, 8, 9, 10 ,12]
y = [7, 9, 12, 16, 20]

plt.plot(x, y)
plt.xlabel('X Data')
plt.ylabel('Y Data')
plt.show()