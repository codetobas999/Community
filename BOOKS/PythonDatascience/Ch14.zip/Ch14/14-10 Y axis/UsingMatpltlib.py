import matplotlib.pyplot as plt
import numpy as np

y = np.array([12, 8, 15, 7, 16, 10])

plt.plot(y)
plt.show()