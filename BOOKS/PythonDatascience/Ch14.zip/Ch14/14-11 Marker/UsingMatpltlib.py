import matplotlib.pyplot as plt

x = [5, 8, 9, 10 ,12]
y = [7, 9, 12, 16, 20]

plt.plot(x, y, marker='o')
plt.show()