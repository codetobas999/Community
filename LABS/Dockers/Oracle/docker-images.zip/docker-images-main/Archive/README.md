# Archived content

The projects in this section have been archived and should be used for
reference purposes only.

Note that documentation in each project has not been updated, so some paths
may now be invalid.

- [ContainerCloud](./ContainerCloud)
- [Oracle Data Integrator](./OracleDataIntegrator)
- [Oracle Enterprise Data Quality](./OracleEDQ)
- [Oracle Tuxedo](./OracleTuxedo)
