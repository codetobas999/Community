#!/bin/bash
echo "Environment: $(uname -a)";
