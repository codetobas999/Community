Oracle Database on Docker - TESTS
===============
This folder contains tests for Docker images. It makes it easier to test the integrity of those images after a change to the build files.

## How to run all tests
Copy all necessary binaries into the `bin` folder, the script will copy it in the right place automatically.
Call `./runAllTests.sh`, on a positive outcome this script will return without any errors.

## Copyright
Copyright (c) 2014-2017 Oracle and/or its affiliates. All rights reserved.
