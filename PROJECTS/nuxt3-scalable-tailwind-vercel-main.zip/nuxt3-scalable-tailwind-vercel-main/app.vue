<!-- 
<template>
  <div class="flex justify-center items-center h-screen">
    <h1 class="text-3xl font-bold text-purple-600 animate-bounce">
      <Icon name="icon-park:home-two"></Icon> 
      <Icon name="ic:twotone-wb-sunny"></Icon> Hello Nuxt 3
    </h1>
</div>
</template> 
-->

<template>

  <Head>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@300;400;500&display=swap" rel="stylesheet">
  </Head>

  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>

</template>
