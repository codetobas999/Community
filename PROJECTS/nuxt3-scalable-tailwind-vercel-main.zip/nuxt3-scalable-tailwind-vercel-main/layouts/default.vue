<script lang="ts" setup></script>

<template>
  <div>
    <AppHeader />

    <div class="mx-auto px-4 sm:px-0">
      <slot />
    </div>
    
    <AppFooter />
  </div>
</template>

<style scoped></style>
