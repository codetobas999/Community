<script lang="ts" setup>
useHead({
  title: "Contact",
  meta: [
    {
      name: "description",
      content: "Contact",
    },
  ],
});
</script>

<template>
  <section class="bg-gray-100">
    <div class="container mx-auto py-12 flex items-center flex-wrap">
      <h1 class="text-2xl font-bold">Contact us</h1>
      <p class="py-8">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Odit atque eos reiciendis! Deserunt facere nemo doloribus quae tempore. Itaque non possimus soluta delectus alias consectetur adipisci libero minima nam explicabo!</p>
    </div>
  </section>
</template>

<style scoped>

</style>