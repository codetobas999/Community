<script lang="ts" setup></script>

<template>
  <footer class="px-4 sm:px-0 bg-blue-700 text-white">
    <div
      class="container py-4 mx-auto flex flex-col sm:flex-row justify-between gap-2 sm:items-center"
    >
      <a href="#" class="font-semibold text-lg text-white">Nuxt Tailwind</a>
      <div class="text-sm">
        Nuxt Tailwind by
        <a
          href="#"
          class="font-semibold text-white"
        >
          IT Genius
        </a>
        . All rights reserved
      </div>
    </div>
  </footer>
</template>

<style scoped></style>
