<script lang="ts" setup>
  useHead({
    title: 'Blog',
    meta: [
      { 
        name: 'description', 
        content: 'Blog Nuxt 3, IT Genius Engineering' 
      },
      {
        name: 'keywords',
        content: 'Blog, Nuxt 3, Learning Nuxt 3'
      },
    ],
  })
</script>

<template>
  <div>
    <h1 class="text-4xl mb-6">Blog</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt asperiores eos maxime voluptatibus sint deleniti nesciunt voluptate, tempore explicabo velit dolores odio saepe provident tenetur commodi consequuntur ducimus officiis obcaecati.</p>
  </div>
</template>

<style scoped></style>
