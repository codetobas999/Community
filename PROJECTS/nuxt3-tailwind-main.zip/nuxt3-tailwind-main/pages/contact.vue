<script lang="ts" setup>
  useHead({
    title: 'Contact',
    meta: [
      { 
        name: 'description', 
        content: 'Contact Nuxt 3, IT Genius Engineering' 
      },
      {
        name: 'keywords',
        content: 'Contact, Nuxt 3, Learning Nuxt 3'
      },
    ],
  })
</script>

<template>
  <div>
    <h1 class="text-4xl mb-6">Contact</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti soluta cupiditate accusamus illum, quibusdam velit harum in neque ullam doloribus rerum animi ipsam minima sequi maxime ad nostrum impedit nam.</p>
  </div>
</template>

<style scoped></style>
