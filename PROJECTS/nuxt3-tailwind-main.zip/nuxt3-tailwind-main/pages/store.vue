<script lang="ts" setup>
  useHead({
    title: 'Store',
    meta: [
      { 
        name: 'description', 
        content: 'Store Nuxt 3, IT Genius Engineering' 
      },
      {
        name: 'keywords',
        content: 'Store, Nuxt 3, Learning Nuxt 3'
      },
    ],
  })
</script>

<template>
  <div>
    <h1 class="text-4xl mb-6">Store</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid eaque incidunt ipsum ratione, laudantium voluptatum! Tempora culpa architecto labore beatae repellat, explicabo, unde sequi ea nemo aspernatur, saepe optio asperiores!</p>
  </div>
</template>

<style scoped></style>
