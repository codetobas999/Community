# OpenProject Deploy

Recipes and examples for deploying OpenProject using Docker, Docker Compose, Kubernetes, etc.

* [Docker Compose](./compose/)
